//////////////////////////////////////////////////////////////////////////////////
//              说明:
//              ----------------------------------------------------------------
//              GND    电源地
//              VCC  接5V或3.3v电源
//              D0   C5（SCL）
//              D1   C7（SDA）
//              CS   C9
//              RST  C11
//              DC   C13
//              ----------------------------------------------------------------
//******************************************************************************/
#ifndef __OLED_H
#define __OLED_H


#include "common.h"
//#include "include.h"
//#include "sys.h"
//#include "stdlib.h"

#define  u8 unsigned char
#define  u32 unsigned int

#define OLED_CMD  0	//写命令
#define OLED_DATA 1	//写数据
#define OLED_MODE 0

// OLED_CS 	 	片选
// OLED_RST 	复位
// OLED_DC 	 	数据/命令控制
// OLED_SCL  	时钟 D0(SCLK)
// OLED_SDIN	D1(MOSI) 数据


//#define OLED_DC PTA19_OUT
//#define OLED_RST PTA24_OUT
#define OLED_CS PTA9_O
#define OLED_DC PTA13_O
#define OLED_RST PTA11_O
#define OLED_SDIN PTA12_O
#define OLED_SCL PTA10_O


#define OLED_CS_Clr()  OLED_CS=0
#define OLED_CS_Set()  OLED_CS=1

#define OLED_RST_Clr() OLED_RST=0
#define OLED_RST_Set() OLED_RST=1

#define OLED_DC_Clr() OLED_DC=0
#define OLED_DC_Set() OLED_DC=1

#define OLED_SCLK_Clr() OLED_SCL=0
#define OLED_SCLK_Set() OLED_SCL=1

#define OLED_SDIN_Clr() OLED_SDIN=0
#define OLED_SDIN_Set() OLED_SDIN=1;





//OLED模式设置
//0:4线串行模式
//1:并行8080模式

#define SIZE 16
#define XLevelL		0x02
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF
#define X_WIDTH 	128
#define Y_WIDTH 	64
//-----------------OLED端口定义----------------


void delay_ms(unsigned int ms);
void OLED_GPIO_Init();
void SPI_OLED_Init();



//OLED控制用函数
void OLED_WR_Byte(u8 dat,u8 cmd);
void OLED_Display_On(void);
void OLED_Display_Off(void);
extern void OLED_Init(void);
void OLED_GPIO_Init();
void SPI_OLED_Init();
extern void OLED_Clear(void);
void OLED_DrawPoint(u8 x,u8 y,u8 t);
void OLED_Fill(u8 x1,u8 y1,u8 x2,u8 y2,u8 dot);
extern void OLED_ShowChar(u8 x,u8 y,u8 chr);
extern void OLED_ShowNum(u8 x,u8 y,int num,u8 len,u8 size2);
extern void OLED_ShowString(u8 x,u8 y, u8 *p);
void OLED_Set_Pos(unsigned char x, unsigned char y);
void OLED_ShowCHinese(u8 x,u8 y,u8 no);
void OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);
#endif




