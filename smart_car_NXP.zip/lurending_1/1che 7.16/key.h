#ifndef _KEY_H_
#define _KEY_H_



extern void init_gpio();
void Key_Isr();

#endif 