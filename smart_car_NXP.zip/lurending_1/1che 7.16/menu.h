#ifndef _MENU_H_
#define _MENU_H_

#include "common.h"

#include "streer.h"
#include "motor.h"

extern int16 qd_result;
extern void showsend(void);
extern void showsend_debug(void);
#endif 