#include "common.h"
#include "motor.h"
#include "SDS.h"

float32 dp;
float32 dd;
float32 di;
float32 Motorset = 0;           //�������ֵ
int8 Stop_Flag = 0;
int8 Stop0 = 0;
//float32 Motorset1 =  20;      //��������ֵ
float32 dPIDoutput;
float32 R_Out = 0;
float32 R_In = 0;    //PID�������
PIDStruct *dPID;

//*****************************************************************************//
//********************************PID�㷨**************************************//
//*****************************************************************************//
void PIDmotorCalc(PIDStruct *motorC, float32  real)
{
    /*΢�����е�PID����(������)*/
    motorC ->Error = (motorC ->motorset) - real;  
    //motorC ->Error = setpoint - real;
    /*//��ͨ��PID
    motorC->PIDoutput = (motorC ->Kp)*((motorC ->Error) - (motorC ->PrevError1))
                        + (motorC ->Ki)*(motorC ->Error)
                        + (motorC ->Kd)*((motorC ->Error) - 2*(motorC ->PrevError1) + (motorC ->PrevError2));*/    
    //΢�����е�PID
    motorC->PIDoutput = (motorC ->Kp)*((motorC ->Error) - (motorC ->PrevError1))
                        +(motorC ->Ki)*(motorC ->Error)
                        +(motorC ->Kd)* ((motorC ->CV[0]) - 2 * (motorC ->CV[1]) + (motorC ->CV[2]))
					 - (motorC ->Kd) * ((motorC ->CV[0]) - (motorC ->CV[1]));
    //�����ֱ��ͣ����û��ַ��뷨��
    if((motorC ->Error > ErrorMAX)||(motorC ->Error < -ErrorMAX))
    {
        motorC->PIDoutput -= (motorC ->Ki)*(motorC ->Error);
    }
    
    //�����ĵ���
    motorC ->CV[0] = (motorC ->CV[1]) + motorC->PIDoutput;
    //motorC->PIDOut = motorC->PIDOut + motorC->PIDoutput;                                                                                 
    motorC ->CV[2] = motorC ->CV[1];
    //motorC->PrevError2 = motorC->PrevError1;
    motorC ->CV[1] = motorC ->CV[0];
    //motorC->PrevError1 = motorC->Error;
    motorC ->PrevError1 = motorC ->Error;
    
////////////////////////////////////��������//////////////////////////////////   
        if(dPID ->Error > motorThersh)
	{                
              DianJi_Changeduty(4000);     //5800             
	}
	else if(dPID ->Error < -motorThersh)
	{    
              DianJi_Changeduty(-4000);           
	}
	else
        {
              DianJi_Changeduty(motorC ->CV[0]);
           // LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch2, (int32)rout);
        }      
}  
//*****************************************************************************//
//*******************************���PID��ʼ��**********************************//
//*****************************************************************************//
void dpid_init(void)
{
    dPID = (PIDStruct *)malloc(sizeof(PIDStruct));
    dp=dPID ->Kp =24;       //һ��22       ����
    di=dPID ->Ki =0.4;        //    0.28    
    dd=dPID ->Kd =0;        //    0
    dPID ->Error = 0;
    dPID ->PrevError1 = 0;
    dPID ->PrevError2 = 0;
    dPID ->PIDOut = 0;
    dPID ->CV[0] =  0;
    dPID ->CV[1] =  0;
    dPID ->CV[2] =  0;
    dPID ->motorset = Motorset;
}
//*****************************************************************************//
//*******************************�ı���PWMֵ**********************************//
//*****************************************************************************//
void DianJi_Changeduty(float32 PIDresult)
{
    if(PIDresult>5000)  //6000
        PIDresult = 5000;
    if(PIDresult<-5000)
        PIDresult = -5000;
    if(PIDresult >= 0)
    {
        //LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch3, (uint32)PIDresult);
        //LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch2, 0);
        
        LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch2, (uint32)PIDresult);                      //��Ϊ�����廻������Ҫ��һ������ת��ʱ��
        LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch3, 0);
    }
    else
    {
        //LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch2, (uint32)(-PIDresult));
        //LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch3, 0);
        
        LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch3, (uint32)(-PIDresult));
        LPLD_FTM_PWM_ChangeDuty(FTM0, FTM_Ch2, 0);
    }
}
