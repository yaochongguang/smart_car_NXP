#ifndef _QD_H_
#define _QD_H_

extern void bianmaqi_init(void);
extern void pit_init(void);
extern void pit_isr(void);
extern void delay(uint16 n);
extern FTM_InitTypeDef ftm1_init_struct;

#endif  //_QD_H_