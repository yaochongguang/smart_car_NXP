#include "zhongduan.h"
//*****************************************************************************//
//*****************************��ʼ���ж����ȼ�********************************//
//*****************************************************************************//
void NVIC_Init(void)
{
	NVIC_InitTypeDef nvic_init_struct;

	//����PIT0��NVIC����
	nvic_init_struct.NVIC_IRQChannel = PIT3_IRQn;
	nvic_init_struct.NVIC_IRQChannelGroupPriority = NVIC_PriorityGroup_3;
	nvic_init_struct.NVIC_IRQChannelPreemptionPriority = 2;
	nvic_init_struct.NVIC_IRQChannelSubPriority = 1;
	nvic_init_struct.NVIC_IRQChannelEnable = FALSE;
	LPLD_NVIC_Init(nvic_init_struct);
	//����portb��portc��NVIC����
	nvic_init_struct.NVIC_IRQChannel = PORTC_IRQn;
	nvic_init_struct.NVIC_IRQChannelGroupPriority = NVIC_PriorityGroup_3;
	nvic_init_struct.NVIC_IRQChannelPreemptionPriority = 4;
	nvic_init_struct.NVIC_IRQChannelSubPriority = 1;
	nvic_init_struct.NVIC_IRQChannelEnable = TRUE;
	LPLD_NVIC_Init(nvic_init_struct);
	//����PORTA��NVIC����
	nvic_init_struct.NVIC_IRQChannel = PORTA_IRQn;
	nvic_init_struct.NVIC_IRQChannelGroupPriority = NVIC_PriorityGroup_3;
	nvic_init_struct.NVIC_IRQChannelPreemptionPriority = 3;
	nvic_init_struct.NVIC_IRQChannelSubPriority = 1;
	nvic_init_struct.NVIC_IRQChannelEnable = TRUE;
	LPLD_NVIC_Init(nvic_init_struct);
        
        //����ԧ��ģ������ȼ�
        nvic_init_struct.NVIC_IRQChannel = PORTD_IRQn;
	nvic_init_struct.NVIC_IRQChannelGroupPriority = NVIC_PriorityGroup_3;
	nvic_init_struct.NVIC_IRQChannelPreemptionPriority = 5;
	nvic_init_struct.NVIC_IRQChannelSubPriority = 1;
	nvic_init_struct.NVIC_IRQChannelEnable = TRUE;
	LPLD_NVIC_Init(nvic_init_struct);

}