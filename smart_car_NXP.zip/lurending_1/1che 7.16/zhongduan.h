#ifndef _ZHONGDUAN_H_
#define _ZHONGDUAN_H_

#include "common.h"

extern void NVIC_Init(void);
extern NVIC_InitTypeDef nvic_init_struct;

#endif