#include "common.h"
#include "streer.h"
#include "motor.h"
#include "qd.h"
#include "yuanyang.h"
#include "zhongduan.h"
#include "key.h"
#include "menu.h"
#include "LPLD_OLED.h"
#include "VCAN_NRF24L0.h"
#include "SDS.h"

//��������
void pwm_init(void);
void pit_init(void);
void pit3_isr(void);

//��������
FTM_InitTypeDef ftm_init_struct;
PIT_InitTypeDef pit3_init_struct;
int16 qd_result=0;
int8 Flag_10ms = 0,Flag_100ms = 0,Flag_5ms = 0,Flag_100mss = 0;
int8 tingche = 0;
int32 shijian = 0;
int8 fajishu = 0;
int8 yuanhuanold;

void main (void)
{
    Stop_Flag = 1;
    Stop0 = 0;
    Motorset = 0;
    chuhuan = 1;
    chuhuanshijian = 155;
    qianhou = 0;
    OLED_Init();        //OLED��ʾ
    init_gpio();        //������ң�صĳ�ʼ��
    gpio_init();        //ԧ��ģ�������ö˿ڵĳ�ʼ��
    nrf_init();
   // fache();
    NVIC_Init();
    pwm_init();         //����ĳ�ʼ��
    adc_init();         //��вɼ��ĳ�ʼ��
    bianmaqi_init(); 
    uart_init();          
    st_pid_init();      //���PID��ʼ��
    pwm0_init();        //���PWM��ʼ��
    dpid_init();        //���PID��ʼ��    
    cheju_pid_init();
    pit_init();         //������ʱ��
    while(1)
    {      
//    	showsend(); 
        showsend_debug();       //���Բ���
      	//delay(10); 
        lukuang();      //���·��
        
        if( panduan == 2)
        {
        if(qianhou == 1)
          qianhou = 0;
        else 
          qianhou = 1;
        panduan = 0;
        }
        
        if(PTC1_I == 0 || PTC2_I == 0 || PTC4_I == 0)
        {
            if(shijian == 0 || shijian>1000)
            {
                tingche ++;
                shijian = 1;
            }
            
        }
        
        if(tingche == 2)
        {
            Motorset = 0;
            {
                dPID ->Kp = 25;                 //25
                dPID ->Ki = 0.6;                //0.6
                dPID ->Kd = 0;
            }
            Stop_Flag = 1;
            tingche = 0;
            shijian = 0;
        }


    } 
}
//*****************************************************************************//
//***************************��ʼ�����FTM��PWM�������************************//
//*****************************************************************************//
void pwm_init(void)
{
    ftm_init_struct.FTM_Ftmx = FTM0;	          //ʹ��FTM0ͨ��
    ftm_init_struct.FTM_Mode = FTM_MODE_PWM;	  //ʹ��PWMģʽ
    ftm_init_struct.FTM_PwmFreq = 60000;	  //PWMƵ��һ��10000    ����20000
    LPLD_FTM_Init(ftm_init_struct);  
    LPLD_FTM_PWM_Enable(FTM0,                     //ʹ��FTM0
                        FTM_Ch2,                  //ʹ��Ch2ͨ��
                        1000,                        //ռ�ձ�
                        PTA5,                     //ʹ��Ch2ͨ����PTA5����
                        ALIGN_LEFT                //���������
                       );  
    LPLD_FTM_PWM_Enable(FTM0,                     //ʹ��FTM0                                      //�����ö���ʱ��Ϊ��������������԰�����ת��һ�£�����������������������
                        FTM_Ch3,                  //ʹ��Ch3ͨ��
                        0,                     //ռ�ձ�
                        PTA6,                     //ʹ��Ch3ͨ����PTA6����
                        ALIGN_LEFT                //���������
                       ); 
}
////////////////////////////////////PIT��ʼ��//////////////////////////////////
void pit_init(void)
{
    //����PIT3����
    pit3_init_struct.PIT_Pitx = PIT3;
    pit3_init_struct.PIT_PeriodMs = 10;     //������Ӧ����5�����һ������
    pit3_init_struct.PIT_Isr = pit3_isr;  //�����жϺ���
    //��ʼ��PIT3
    LPLD_PIT_Init(pit3_init_struct);  
    //ʹ��PIT3
    LPLD_PIT_EnableIrq(pit3_init_struct);
}
//*****************************************************************************//
//**********************************PIT3�жϺ���*******************************//
//*****************************************************************************//
void pit3_isr(void)
{
    //Flag_10ms++;
    
    Flag_100ms++;
    Flag_10ms++;    
    qd_result = LPLD_FTM_GetCounter(FTM1);     //ȡ������ֵ
    LPLD_FTM_ClearCounter(FTM1);               //��ռ���
    
    if(shoubiaozhi >= 1)
    {
          nrf_handler();
          shou = nrf_rx(buff,DATA_PACKET);
          //shoubiaozhi ++;

    }
    else if(fabiaozhi >= 1)
    {
           nrf_handler();
	   nrf_tx(fa3,DATA_PACKET); 
           //fabiaozhi ++;
           if(fabiaozhi>=400)
             fabiaozhi = 0;
    }
    
    if(tingche > 0)
    {
      shijian ++;
      if(shijian>500)
        shijian = 1200;
      if(Stop_Flag == 1)
      {
          tingche = 0;
          shijian = 0;
      }
    }
    
    if( podao == 1 )
    {
      
    podaoshijian++;
    
    if(podaoshijian > 40)
      podaoshijian = 45;
    
    }
    //diangan();                             //ȡ���ֵ5����ȡһ�ε��ֵ

    
    if(yuanhuan == 1)
    {
      yuanhuanshijian ++;
      if(yuanhuanshijian>10)
      {
          yuanhuanshijian = 11;
      }
        
    }

      if(chuhuan ==1)
      {
          chuhuanshijian ++;
          if(chuhuanshijian>50)
            chuhuanshijian = 55;
      }
/*    if(shizi==1)
    {
         shizi_time0 ++;
         if (shizi_time0 >= 1500)
         {
             shizi_time0 = 0; 
             shizi = 1;
         }
    }*/
    //if(Flag_5ms%2==0)
    //{
      //  qd_result = LPLD_FTM_GetCounter(FTM1);     //ȡ������ֵ
      //  LPLD_FTM_ClearCounter(FTM1);               //��ռ���    10����ȡһ�α�����ֵ  
    //}
    //��һ��10ms
    if(Flag_10ms==1)
    {
  
        diangan();
        streer_pid();                          //���pid  
    }
    if(Flag_10ms==2)
    {
            if(Stop_Flag == 1)
            {
              dPID ->motorset = 0;
              dPID ->Kp = 25;                 //25
              dPID ->Ki = 0.6;                //0.6
              dPID ->Kd = 0;
            }
            
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////ʮ�ֳ���/////////////////////////////////////////////////////////////////////////
	  /*else if (shizi == 1 )
		{	
			if(qianhou == 1)
			{				
				{
				dPID ->motorset = 200;
				if (PIDOutput > STEER_MID_DUTY + 130)
					PIDOutput = STEER_MID_DUTY + 130;
				if (PIDOutput < STEER_MID_DUTY - 130)
					PIDOutput = STEER_MID_DUTY - 130;

				//LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)PIDOutput);
				}
		}
            else if (qianhou == 0)
            {      
                if (shizi_time0 <= 80)
				{
				dPID ->motorset = 150;
				//LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(STEER_MID_DUTY + 80));
				}
			else if(shizi_time0 <= 160&&shizi_time0 > 80)
				{
                                dPID ->motorset = -150;
				LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(STEER_MID_DUTY + 80));
				}
			else 
				{
				dPID ->motorset = 200;
				//LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)PIDOutput);                                
				if (PIDOutput > STEER_MID_DUTY + 130)
					PIDOutput = STEER_MID_DUTY + 130;
				if (PIDOutput < STEER_MID_DUTY - 130)
					PIDOutput = STEER_MID_DUTY - 130;
                }

            }
                }*/
		              
            else if(qianhou == 1)
             {
               if(yuanhuan == 1&& shizi!=1)
               {
                //if(yuanhuanli2 == 1)                                               
                {
                    dPID ->motorset = 200;
                  if(yuanhuanli1 == 1)
                    dPID ->motorset = 200;
                  if(yuanhuanli2 == 1)
                    dPID ->motorset = 200;              
                 
                 }
               }

                if(yuanhuan != 1&&shizi != 1)
                {
 
               
                  if( rIn <40 && rIn > -40)  
                  {
                   if(PTB23_I == 1 && PTB21_I == 1)
                     Motorset1 = 200;                               ////////////////////////////////////////////////////////////
                   else if(PTB23_I == 0 && PTB21_I == 0)
                     Motorset1 = 215; 
                   else
                     Motorset1 = 175; 
                    dPID ->motorset = Motorset ;
                  }
                  else  if( rIn <70 && rIn > -70)
                  {
                   if(PTB23_I == 1 && PTB21_I == 1)
                     Motorset1 = 200;                               ////////////////////////////////////////////////////////////
                   else if(PTB23_I == 0 && PTB21_I == 0)
                     Motorset1 = 215; 
                   else
                     Motorset1 = 175; 
                    dPID ->motorset = Motorset ;
                  }
                  else
                  {
                   if(PTB23_I == 1 && PTB21_I == 1)
                     Motorset1 = 200;                               ////////////////////////////////////////////////////////////
                   else if(PTB23_I == 0 && PTB21_I == 0)
                     Motorset1 = 215; 
                   else
                     Motorset1 = 175; 
                    dPID ->motorset = Motorset ;
                  }
               
                }
              }
             else
             {
               if(yuanhuan == 1&&shizi!=1)
               {
                  dPID ->motorset = 225;
                  if(yuanhuanli1 == 1)
                    dPID ->motorset = 225;
                  if(yuanhuanli2 == 1)
                  {
                    if(PTB19_I == 0)
                    {
                      //nrf_handler();
                      //shou = nrf_rx(buff,DATA_PACKET);
                      //if(shoubiaozhi!=0)
                      shoubiaozhi ++;
                    }
                 if( buff[0] !='3'&& PTB19_I == 0 && shoubiaozhi < 50 && shizi!=1 )  ////û���յ�
                 {
                 dPID ->motorset = 0;
                 dPID ->Kp = 25;                //25
                 dPID ->Ki = 0.6;                //0.6
                 }
                  
                  if(shoubiaozhi >= 50 || buff[0] == '3' || PTB19_I == 1 && shizi!=1)
                  {                                 
                 dPID ->Kp = 24;
                 dPID ->Ki = 0.4;
                 dPID ->motorset = 225; 
                 //qianhou=1;
                 //shoubiaozhi = 0;
                  }
                  }
                  
                }
               
                                
               else if(yuanhuan != 1&&shizi!=1)
               {
                 if(PTB19_I == 0)
                 {
                     // nrf_handler();
	             // nrf_tx(fa3,DATA_PACKET); 
                   shoubiaozhi  = 0;
                   fabiaozhi ++;
                 }
                 
                 {
                   if( rIn <40 && rIn > -40)  
                  {
                      //Motorset1 = 255;
                      skp = 1.3;
                      skd = 4.5;
                   if(PTB23_I == 1 && PTB21_I == 1)
                    dPID ->motorset = 200;              ////////////////////////////////////////////////////////////////////////////////////////
                   else if(PTB23_I == 0 && PTB21_I == 0)
                    dPID ->motorset = 215; 
                   else
                    dPID ->motorset = 175; 
                  }
                  else  
                  {
                     // Motorset1 = 235;
                    skp = skp1; 
                    skd = skd1; 
                   if(PTB23_I == 1 && PTB21_I == 1)
                    dPID ->motorset = 200;              ////////////////////////////////////////////////////////////////////////////////////////
                   else if(PTB23_I == 0 && PTB21_I == 0)
                    dPID ->motorset = 215; 
                   else
                    dPID ->motorset = 175; 
                  }

                 }
               }

            }
            
                R_In = -qd_result;
                PIDmotorCalc(dPID, R_In);              //���pid    
                Flag_10ms = 0;
           yuanhuanold = yuanhuan;
    }
    if(Flag_100ms==5)
    {
//                                                                  Twincar_cheju_kongzhi();
        //nrf_handler();
        //nrf_tx(fa1,DATA_PACKET);  
       // SDS_OutData[0] = (float32)(yuanhuan*500);
      //  SDS_OutData[1] = (float32)(yuanhuanli1*1000);
       // SDS_OutData[2] = (float32)(yuanhuanli2*1500);
       // SDS_OutData[3] = (float32)(biaozhi*1000);
                                                            //SDS_OutData[1] = (float32)(yuanhuanli*1000);
                                                            //SDS_OutData[0] = (float32)(erdiu*1000);
                                                            //SDS_OutData[1] = (float32)(dgAD[0]);
                                                            //SDS_OutData[0] = (float32)(cheju);
                                                            //SDS_OutData[1] = (float32)(Motorset);
                                                            //SDS_OutData[2] = (float32)(dgAD[5]);
                                                            //SDS_OutData[3] = (float32)(yuanhuan*1000);
                                                            //SDS_OutPut_Data(SDS_OutData);    //����Ŀ��ֵ��ʵ��ֵ�Լ�I,D�������ʾ����
      
      Flag_100mss ++;
      if(qianhou == 1&&shizi!=1)
      {
          Twincar_cheju_kongzhi();
          
      }
      
      
      
        if(Stop_Flag == 1 && Stop0 == 0)
        {
         if(qianhou == 1)              ///////hou
         {
          if(buff[0] != '1')
           {
            nrf_handler();
            shou = nrf_rx(buff,DATA_PACKET); 
           }
        
          else
           {
             nrf_handler();
             nrf_tx(fa2,DATA_PACKET);  
             fajishu ++;
             if(fajishu == 3)
             {
             Stop_Flag = 0;
             fajishu = 0;
             }
           }
         }
         else               /////////////qian
         {
         if(Flag_100mss == 1)
         {
             nrf_handler();
             nrf_tx(fa1,DATA_PACKET);  
         }
         else
         {
            nrf_handler();
            shou = nrf_rx(buff,DATA_PACKET); 
         }
         
         if(buff[0] == '2')
           Stop_Flag = 0;
         }
        
        }
        Flag_100ms = 0;
       if(Flag_100mss == 2)
        Flag_100mss = 0;
        
        
    }
    
    
}