#include "common.h"
#include "key.h"
#include "streer.h"
#include "qd.h"
#include "motor.h"
#include "yuanyang.h"

GPIO_InitTypeDef key0_init_struct;
GPIO_InitTypeDef key1_init_struct;
GPIO_InitTypeDef key2_init_struct;
GPIO_InitTypeDef ghg_init_struct;
//******************************************************************************//
//*****************************��ʼ���������뿪��ң��****************************//
//*****************************************************************************//
void init_gpio(void)
{
  // ����GPIO����,����,�ڲ��������������ж�
  key0_init_struct.GPIO_PTx = PTA;      //PORTA
  key0_init_struct.GPIO_Pins = GPIO_Pin19|GPIO_Pin24|GPIO_Pin25|GPIO_Pin27;             //ң�ؿ���  
  key0_init_struct.GPIO_Dir = DIR_INPUT;        //����
  key0_init_struct.GPIO_PinControl = INPUT_PULL_UP|IRQC_FA;     //�ڲ�����|�����ж�
  key0_init_struct.GPIO_Isr = Key_Isr;
  
  key1_init_struct.GPIO_PTx = PTC;      //PORTC
  key1_init_struct.GPIO_Pins = GPIO_Pin5|GPIO_Pin7|GPIO_Pin9|GPIO_Pin11;                //�Ƕ�������    
  key1_init_struct.GPIO_Dir = DIR_INPUT;        //����
  key1_init_struct.GPIO_PinControl = INPUT_PULL_UP|IRQC_FA;     //�ڲ�����|�����ж�
  key1_init_struct.GPIO_Isr = Key_Isr;
  
  key2_init_struct.GPIO_PTx = PTB;      //PORTB
  key2_init_struct.GPIO_Pins = GPIO_Pin23|GPIO_Pin17|GPIO_Pin19|GPIO_Pin21;             //���뿪�� 
  key2_init_struct.GPIO_Dir = DIR_INPUT;        //����
  key2_init_struct.GPIO_PinControl = INPUT_PULL_UP|IRQC_DIS;     //�ڲ�����|�������ж�
  
  ghg_init_struct.GPIO_PTx = PTC;      //PORTC
  ghg_init_struct.GPIO_Pins = GPIO_Pin1|GPIO_Pin2|GPIO_Pin4;                //�Ǹɻɹ�    
  ghg_init_struct.GPIO_Dir = DIR_INPUT;        //����
  ghg_init_struct.GPIO_PinControl = INPUT_PULL_UP|IRQC_DIS;     //�ڲ�����|�����ж�
 // ghg_init_struct.GPIO_Isr = Key_Isr;

  LPLD_GPIO_EnableIrq(key0_init_struct);
  LPLD_GPIO_EnableIrq(key1_init_struct);
  //LPLD_GPIO_EnableIrq(ghg_init_struct);
  LPLD_GPIO_Init(key0_init_struct);
  LPLD_GPIO_Init(key1_init_struct);
  LPLD_GPIO_Init(key2_init_struct);
  LPLD_GPIO_Init(ghg_init_struct);
}
//*****************************************************************************//
//*****************************�����ⲿ�жϺ���*********************************//
//*****************************************************************************//
void Key_Isr()
{
 if(LPLD_GPIO_IsPinxExt(PORTC, GPIO_Pin5))
    {
      //ȥ��
      delay(100);
      if(PTC5_I == 0)
      {
//        juskp += 0.1;
        if(PTB19_I == 0)
         yuanjiao2 -= 1;
        else
         skp2 += 0.05;
        //skp2 += 0.2;
      }
    }
  if(LPLD_GPIO_IsPinxExt(PORTC, GPIO_Pin7))
    {
      //ȥ��
      delay(100);
      if(PTC7_I==0)
      {
//        juskp -= 0.1;
        if(PTB19_I == 0)
         yuanjiao2 -= 1;
        else
         skp2 -= 0.05;
        //skp2 -= 0.2;
      }
    }
  if(LPLD_GPIO_IsPinxExt(PORTC, GPIO_Pin9))
    {
    
      //ȥ��
      delay(100);
      if(PTC9_I == 0)
      {
        //juskd -= 0.5;
        if(PTB19_I == 0)
         yuanjiao1 -= 1;
        else
         skd -= 0.1;
        //ski2 -= 0.1;
        
      }
    
    }
  if(LPLD_GPIO_IsPinxExt(PORTC, GPIO_Pin11))
    {
      //ȥ��
      delay(100);
      if(PTC11_I == 0)
      {
        //juskd += 0.5;
        if(PTB19_I == 0)
         yuanjiao1 += 1;
        else
         skd += 0.1;
        //ski2 += 0.1;
      }
    }
////////////////////////////////////ң��ͣ��//////////////////////////////////
    if(LPLD_GPIO_IsPinxExt(PORTA, GPIO_Pin19))
    {
            Motorset = 0;
            Stop_Flag = 1;
            Stop0 = 1;
            //ͣ���ж�
            //if(Motorset == 0)
            {
            dPID ->Kp = 25;                 //25
            dPID ->Ki = 0.6;                //0.6
            dPID ->Kd = 0;
            }
       
    } 
//********************************************************//
    if(LPLD_GPIO_IsPinxExt(PORTA, GPIO_Pin24))
      Motorset += 5;
    if(LPLD_GPIO_IsPinxExt(PORTA, GPIO_Pin25))
    {
      
        Motorset -= 5;
    }
    if(LPLD_GPIO_IsPinxExt(PORTA, GPIO_Pin27))
    {
        //Motorset = 150;
        Motorset = 200;
        Stop_Flag = 0;
        dPID ->Kp = 24;       
        //dPID ->Kp = 22;
        dPID ->Ki = 0.4;
        dPID ->Kd = 0;           
    }
}

