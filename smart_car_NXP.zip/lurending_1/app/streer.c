#include "common.h"
#include "streer.h"
#include "motor.h"
#include "qd.h"
#include "LPLD_OLED.h"
#include "math.h"
#include "VCAN_NRF24L0.h"
// 8 9 10 11 12 13 14 15                   J14  GND 5V 0 4 7 10                          
//B0 1  4  5  6  7 10 11                   J13  GND 5V 1 5 6 11                                        

//<     |     >
//-          -
// 1che   ad   15     12     9        2che   ad    9    15    12  
//             13            10                    10         13
// 1che    b   11     6      1        2che    b    1    11     6
//              7            4                     4           7

//PID�ṹ��

int16 shoubiaozhi = 0;
int16 fabiaozhi = 0;
//int16 yuanhuanshijian = 0;
int16 chuhuanshijian = 0;
int8 chuhuan = 0;
int8 panduan = 0;

int  STEER_MID_DUTY = 782;                  // һ��782   ���� 799
uint16 i, j, k, temp;    
float32 skp = 1.65, skd = 8.6;                                                                                //skp = 2.79, skd = 9.50;                 //��ͨ·��PD
float32 skp1 = 1.65, skd1 = 8.6;         
float32 skp2 = 2.1, skd2 = 3.5;                 //Բ��PD
float32 skp3 = 3.0, skd3 = 4;                   //����
float32 skp4 = 3.0, skd4 = 4;                   //ʮ��PD
int16 yuanhuanshijian = 0;
int8 shizi = 0;
int8 biaozhi = 0;
int8 shizili0 = 0;
int8 shizili1 = 0;
int8 shizili2 = 0;
int16 shizi_time0 = 0;      //ʮ���ҹ�ʱ��
int8 yuanhuan = 0;
int8 yuanhuanli1 = 0;
int8 yuanhuanli2 = 0;
int8 yuanhuan_time1 = 0;                 //���ڽ�Բ�����
int8 yuanhuan_time2 = 0;                 //���ڻ���Բ�����
int8 qianhou = 0;
int16 podaoshijian = 0;
int16 yuanjiao1 = 13;
int16 yuanjiao2 = 8;
int8 podao = 0;
//int8 erdiu = 0;
//int8 erdiu1 = 0;
int8 cishu = 0;
int8 car_stop_flag = 0;

uint32 data[8][5] = { 0 };                  //���ڴ���������е�������ݲɼ����


float32 dgAD[8] = { 0 };                    //������вɼ����ݴ���֮���ֵ
float32 gyAD[8] = { 0 };                    //������й�һ����ֵ
//********************************************************//
float32 angle = 0;
float32 angle1 = 0;
float32 rOut = 0;                           //PID�����������
float32 rIn = 0;                            //PID�������
float32 PIDOutput = 0;                      //PID���
float32 PIDOutput_old =0;                         //�ϴε�PID���
float32 PIDOutput_old_old =0;              //���ϴε�PID���
PID_S *sPID;
ADC_InitTypeDef adc_init_struct;            //AD�⺯���ṹ��
FTM_InitTypeDef ftm0_init_struct;
uint8 buff[DATA_PACKET];
uint8 *fa1 = "1" ,*fa2 = "2",*fa3 = "3";
int32 shou;
//*****************************************************************************//
//*****************************��ʼ��ADC����ͨ��*******************************//
//*****************************************************************************//
void adc_init(void)
{
	//����ADC��������
	adc_init_struct.ADC_Adcx = ADC1;
	adc_init_struct.ADC_DiffMode = ADC_SE;                      //���˲ɼ�
	adc_init_struct.ADC_BitMode = SE_12BIT;                     //����12λ����
	adc_init_struct.ADC_SampleTimeCfg = SAMTIME_SHORT;          //�̲���ʱ��
	adc_init_struct.ADC_HwAvgSel = HW_4AVG;                     //4��Ӳ��ƽ��
	adc_init_struct.ADC_CalEnable = TRUE;                       //ʹ�ܳ�ʼ��У��
																//��ʼ��ADC
	LPLD_ADC_Init(adc_init_struct);
////////////////////////////////////ʹ����ӦADC��//////////////////////////////////
	LPLD_ADC_Chn_Enable(ADC1, AD8);
	LPLD_ADC_Chn_Enable(ADC1, AD9);
	LPLD_ADC_Chn_Enable(ADC1, AD10);
	LPLD_ADC_Chn_Enable(ADC1, AD11);
	LPLD_ADC_Chn_Enable(ADC1, AD12);
	LPLD_ADC_Chn_Enable(ADC1, AD13);
	LPLD_ADC_Chn_Enable(ADC1, AD14);
	LPLD_ADC_Chn_Enable(ADC1, AD15);
}
//*****************************************************************************//
//****************************��ʼ��FTM��PWM�������***************************//
//*****************************************************************************//
void pwm0_init(void)
{
	ftm0_init_struct.FTM_Ftmx = FTM2;	              //ʹ��FTM2ͨ��
	ftm0_init_struct.FTM_Mode = FTM_MODE_PWM;	      //ʹ��PWMģʽ
	ftm0_init_struct.FTM_PwmFreq = 50;	              //PWMƵ��50Hz  
	LPLD_FTM_Init(ftm0_init_struct);
	LPLD_FTM_PWM_Enable(FTM2,                         //ʹ��FTM0
		FTM_Ch0,                      //ʹ��Ch0ͨ��
		STEER_MID_DUTY,               //��ʼ���Ƕ�0��
		PTB18,                        //ʹ��Ch0ͨ����PTB18����
		ALIGN_LEFT                    //���������
		);
}
//PID����
float PIDCalc(PID_S *pp, float NextPoint)
{
	//int32 dError;     //��ǰ΢��    
	//pp->PrevError = pp -> Error;                 //���¡�֮ǰ��
	pp->Error = pp->SetPoint - NextPoint;          //ƫ�� = �趨Ŀ�� - ����ֵ
	pp->dError = pp->Error - pp->PrevError;        //��ǰ΢�� = ������ - ֮ǰ���
	pp->PrevError = pp->Error;                     //���¡�֮ǰ��
	return(pp->KP*(pp->Error)                      //������ = �������� * ƫ��                   
		+ pp->KD*(pp->dError)                      //΢���� = ΢�ֳ��� * ��ǰ΢��
		);
}
//PID��ʼ��
PID_S* PIDInit(void)
{
	PID_S *PID;
	PID = (PID_S *)malloc(sizeof(PID_S));
	return PID;
}
//PID������ʼ��
void st_pid_init()
{

	sPID = PIDInit();             //��ʼ���ṹ��
	sPID->KP = skp;               //�趨PID��������
	sPID->KD = skd;               //�趨PID΢�ֳ���   
	sPID->SetPoint = 0;           //�趨Ŀ��ֵ
	sPID->Error = 0;
	sPID->PrevError = 0;          //����ֵΪ0
}

//*****************************************************************************//
//***********************�ɼ� �˲� �������Сֵ ��һ��*************************//
//*****************************************************************************//
void diangan(void)
{
	for (i = 0; i<6; i++)                //�˸���е����ݸ��ɼ�5��
	{
               /* //erche
		data[0][i] = LPLD_ADC_Get(ADC1, AD9);
		data[1][i] = LPLD_ADC_Get(ADC1, AD11);
		data[2][i] = LPLD_ADC_Get(ADC1, AD14);
		data[3][i] = LPLD_ADC_Get(ADC1, AD13);
		data[4][i] = LPLD_ADC_Get(ADC1, AD10); */
                
                //yiche
                data[0][i] = LPLD_ADC_Get(ADC1, AD15);
		data[1][i] = LPLD_ADC_Get(ADC1, AD12);
		data[2][i] = LPLD_ADC_Get(ADC1, AD9);
		data[3][i] = LPLD_ADC_Get(ADC1, AD10);
		data[4][i] = LPLD_ADC_Get(ADC1, AD13); 
                data[5][i] = LPLD_ADC_Get(ADC1, AD8); 
	}  
  
////////////////////////////////������ð�����򷽱�ȡ��λ��//////////////////////////////
	for (i = 0; i<6; i++)        //�������
	{
		for (j = 0; j<4; j++)    //5����������
		{
			for (k = 0; k<4 - j; k++)
			{
				if (data[i][k]>data[i][k + 1]) //ǰ�߱Ⱥ�ߴ�����н���
				{
					temp = data[i][k + 1];
					data[i][k + 1] = data[i][k];
					data[i][k] = temp;
				}
			}
		}
	}
	//���������λ���Ĵ洢
	for (i = 0; i<6; i++)
		dgAD[i] = data[i][2];       //����ȡ����λ������dgAD[i]01234
}
//*****************************************************************************//
//**********************************·������************************************//
//*****************************************************************************//
void streer_pid(void)
{
/////////////////////////////////////////Բ������////////////////////////////////////////////////////////////////
        if(yuanhuan == 1 && shizi!= 1)
        {
            angle = 3600 * (sqrt(dgAD[0]) - sqrt(dgAD[2])) / (dgAD[2] + dgAD[0]);
            sPID->KP = skp2;
            sPID->KD = skd2;
            rIn = angle;             
             if(rIn>600)
               rIn = 600;
             if(rIn<-600)
               rIn = -600;
            rOut = PIDCalc(sPID, rIn);         //PID����
            PIDOutput = STEER_MID_DUTY + rOut; //�����ֵ������һ��������ʽ��PID������ 
 
                                                       /* if(yuanhuanli != 1)
                                                        {
                                                          if(qianhou == 0)
                                                          {
                                                            //PIDOutput = STEER_MID_DUTY + 130;
                                                            LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(STEER_MID_DUTY + 120));
                                                          }
                                                          else if(qianhou == 1)
                                                            LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(STEER_MID_DUTY - 80));
                                                        }*/
            
	   // dPID ->motorset = Motorset - 200;
            if(yuanhuan == 1 && yuanhuanli1 != 1&&yuanhuanli2 != 1)
            {
               // Motorset = 100;  
                //PIDOutput = STEER_MID_DUTY +  130; 
               // LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(PIDOutput));
                yuanhuan_time1 ++;
                if(yuanhuan_time1 == yuanjiao1)
                {
                    yuanhuanli1 = 1;
                    yuanhuan_time1 = 0;
                }
            }
            
            
            if(yuanhuanli1 == 1 && yuanhuanli2 != 1)
            {
                       // PIDOutput = STEER_MID_DUTY -  130;
				//LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(PIDOutput));
				yuanhuan_time2++;
                if(yuanhuan_time2 == yuanjiao2)
				{
					//yuanhuanli1 = 0;
					yuanhuanli2 = 1;
					yuanhuan_time2 = 0;
				}
              //  Motorset = 150;
            }
			if (yuanhuanli2 == 1)
			{
				if (PIDOutput > STEER_MID_DUTY + 130)
					PIDOutput = STEER_MID_DUTY + 130;
				if (PIDOutput < STEER_MID_DUTY - 130)
					PIDOutput = STEER_MID_DUTY - 130;
				LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)PIDOutput);
                                biaozhi = 0;

				//Motorset = 200;
			}
            
        }


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////��ͨ����////////////////////////////////////////////////////////////////////////////
		else if(yuanhuan!=1 && shizi!=1) 
		{
			angle1 = 1500 * ((dgAD[3]) - (dgAD[4])) / (dgAD[3] + dgAD[4]);
			angle = 5000 * (sqrt(dgAD[0]) - sqrt(dgAD[2])) / (dgAD[2] + dgAD[0]);   //4500
			sPID->KP = skp;
			sPID->KD = skd;
			rIn = angle;
                        
                        if(dgAD[0]<400 && dgAD[2]<400&&(dgAD[0]-dgAD[2])>-160&&(dgAD[0]-dgAD[2])<160)
                          rIn = angle1;
                          
			if (rIn>600)
			rIn = 600;
			if (rIn<-600)
			rIn = -600;
			rOut = PIDCalc(sPID, rIn);         //PID����
			PIDOutput = STEER_MID_DUTY + rOut; //�����ֵ������һ��������ʽ��PID������
                        
                        /*if(dgAD[0]<100 && dgAD[2]<100)
                        {
                                if(dgAD[4]>dgAD[3])
                                  PIDOutput = STEER_MID_DUTY + 130; 
                                else if(dgAD[3]>dgAD[4])
                                  PIDOutput = STEER_MID_DUTY - 130; 
                        }*/
                        
                        //����
/*                        if(dgAD[0]<150&&dgAD[2]<150&&dgAD[3]<50&&dgAD[4]<50)
                        {
                            if((fabs(dgAD[0]-dgAD[2])<70)&&(fabs(dgAD[3]-dgAD[4])<45))
                            {
                                if(dgAD[2]>dgAD[0])
                                  PIDOutput = STEER_MID_DUTY + 130; 
                                else if(dgAD[0]>dgAD[2])
                                  PIDOutput = STEER_MID_DUTY - 130; 
                            }
                        }
                        
                        
                        
*/                        
                        
                        //if (PTB21_I == 1)
                        {
                        if(dgAD[3]<65 &&dgAD[4]<65)
                        {
                            if((PIDOutput_old-STEER_MID_DUTY)*(PIDOutput_old_old-STEER_MID_DUTY) >0)
                            PIDOutput = PIDOutput_old;
                            else
                              PIDOutput = PIDOutput_old_old;
                        }
                        

                        if((dgAD[3]-dgAD[4])*(dgAD[0]-dgAD[2]) <0)
                        {
                           if((PIDOutput_old-STEER_MID_DUTY)*(PIDOutput_old_old-STEER_MID_DUTY) >0)
                            PIDOutput = PIDOutput_old;
                            else
                              PIDOutput = PIDOutput_old_old;
                            
                        }
                        }

                        
                            if (PIDOutput > STEER_MID_DUTY + 140)
                                    PIDOutput = STEER_MID_DUTY + 140;
                            if (PIDOutput < STEER_MID_DUTY - 140)
                                    PIDOutput = STEER_MID_DUTY - 140;
                            LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)PIDOutput);
                        


		}
        
        PIDOutput_old_old = PIDOutput_old;
        PIDOutput_old = PIDOutput;
        
        
        
}
//*****************************************************************************//
//**********************************·���ж�***********************************//
//*****************************************************************************//
void lukuang(void)
{
	//*************************ʮ��***************************//
	/*if (dgAD[5] >= 600&& dgAD[1] >= 1800)
	{
         shizi = 1;
	}*/
	//*************************Բ��***************************//  
         if(dgAD[1] > 2500)
     {
       
       podao = 1;
       
           if(podaoshijian>40&&dgAD[1] > 2500)
           {
           podao = 0;
           podaoshijian = 0;
           }
     }
      else if (dgAD[0]>=600&&dgAD[0]<=1100&&dgAD[2]>=600&&dgAD[2]<=1100 &&podao == 0 &&(chuhuan == 1)&&(chuhuanshijian >50)&&shizi != 1)
     {
//         if(dgAD[3]>=110&&dgAD[4]>=110&&dgAD[1]<=1500&&dgAD[1]>=800&&dgAD[3]<=450&&dgAD[4]<=450)  
         if(dgAD[3]>=60&&dgAD[4]>=60&&dgAD[1]<=1100&&dgAD[1]>=800&&dgAD[3]<=300&&dgAD[4]<=300&&dgAD[5]>12&&dgAD[5]<120) //dgAD[1]<=1400
         {
                       yuanhuan = 1;
                       panduan++;
                       chuhuan = 0;
                       chuhuanshijian = 0;
         }
     } 
     
     if(yuanhuan == 1 && yuanhuanli1 != 1&&yuanhuanli2 != 1)
     {
            // Motorset = 100;  
       
            if(PTB17_I == 0)
             PIDOutput = STEER_MID_DUTY +  130; 
            else
              PIDOutput = STEER_MID_DUTY -  130; 
            LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(PIDOutput));
            biaozhi = 1;
     }
  
     if(yuanhuanli1 == 1 && yuanhuanli2 != 1)
      {
           if(PTB17_I == 0)
            PIDOutput = STEER_MID_DUTY -  60;
           else
              PIDOutput = STEER_MID_DUTY +  60;
           LPLD_FTM_PWM_ChangeDuty(FTM2, FTM_Ch0, (uint32)(PIDOutput));
           biaozhi = 2;
      }
     
   if(yuanhuan == 1 && yuanhuanli1 == 1 && yuanhuanli2 == 1 && dgAD[1]>1500 && yuanhuanshijian>10)
     {         
         yuanhuanshijian = 0;
         yuanhuan = 0;
         panduan++;
         yuanhuanli1 = 0;
         yuanhuanli2 = 0;      
         
     }

       
}      




void shoufa(void)
{
        //if(dPID ->motorset == 0)
        {
         //nrf_handler(); 
         //nrf_tx(fa1,DATA_PACKET);  
        }
         if( yuanhuan == 1 && yuanhuanli1 == 1 && dgAD[3]>=350 && dgAD[4]>=350 && qianhou == 1) /////////////////////////////////////////////////////////////////////////////////////jinyuanquan
        {
         nrf_handler(); 
         nrf_tx(fa3,DATA_PACKET);  
        }
        //else if( yuanhuan == 0 && yuanhuanli == 0 ) /////////////////////////////////////////////////////////////////////////////////////chuyuanquan
        {
        // nrf_handler();  
        // nrf_tx(fa3,DATA_PACKET); 
        }
        
        nrf_handler();
        shou = nrf_rx(buff,DATA_PACKET); 
}


void fache(void)
{

	if (qianhou == 0)	//ǰ��
	{
		while(buff[0] !='2')		//����������Ϣֱ���յ���Ӧ
		{
                        nrf_handler();
			nrf_tx(fa1,DATA_PACKET);  
			//delay(100);
                        
                        //nrf_handler();
                        //shou = nrf_rx(buff,DATA_PACKET); 
                        
		}

		OLED_ShowString(0, 5, "F Launched");

	}
	else	//��
	{
		while(buff[0] !='1')	//�ȴ�ǰ���ź�
                {
                
                        nrf_handler();
			nrf_tx(fa2,DATA_PACKET);  
			delay(100);
                        
                        nrf_handler();
                        shou = nrf_rx(buff,DATA_PACKET); 
                  
                }

		delay(8);
		OLED_ShowString(0, 5, "B Launched");
	}
}







